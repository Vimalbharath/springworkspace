package com.htc.springbootstarter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootstarterApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootstarterApplication.class, args);
	}

}
